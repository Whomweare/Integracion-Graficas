import axios from 'axios';

const URL_API = "http://localhost:5000";

export const totalProductos = async ()=>{

    const response= await axios.get(`${URL_API}/total-producto-marca`);

    return response.data;
}

export const valorTotal = async ()=>{

    const response= await axios.get(`${URL_API}/valor-total-producto`);

    return response.data;
}

export const valorMinimo = async ()=>{

    const response= await axios.get(`${URL_API}/valor-minimo-producto`);

    return response.data;
}
