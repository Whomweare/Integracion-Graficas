'use client'
import {totalProductos} from '@/app/servicios/api';
import React, { useEffect, useState } from 'react'
import { Bar } from 'react-chartjs-2';


import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend } from 'chart.js';

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function page() {

    const [charData, setCharData] = useState({
        labels: [],
        datasets: [
            {
                label: '',
                data: [],
                backgroundColor: ''
            }
        ]
    });


    useEffect(() => {
        totalProductos()
            .then(data => {

                const dataLabels = data.map((item: any) => item.plannerCode);
                const dataProductos = data.map((item: any) => parseInt(item.cantidad));

                setCharData({
                    labels: dataLabels,
                    datasets: [{
                        label: 'Total de productos por sistema de planificacion',
                        data: dataProductos,
                        backgroundColor: 'rgba(192, 75, 192, 0.6)'
                    }

                    ]
                })

            })
            .catch((error) => console.log('Ocurrio un error'))
    }, []);


    return (
        <div>

            <Bar data={charData}></Bar>
        
        </div>
    )
}