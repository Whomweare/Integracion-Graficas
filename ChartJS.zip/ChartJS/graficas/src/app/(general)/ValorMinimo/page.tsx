'use client'

import { useEffect, useState } from 'react'
import { Pie, Doughnut } from 'react-chartjs-2'
import { valorTotal } from '@/app/servicios/api'

import {Chart as ChartJS, ArcElement, Tooltip, Legend, } from 'chart.js'

ChartJS.register(ArcElement, Tooltip, Legend)

export default function Page() {
    const [charData, setCharData] = useState(null)

    useEffect(() => {
        valorTotal().then((data) => {
            const labels = data.map((item: any) => item.productType)
            const values = data.map((item: any) => parseFloat(item.total))
            
            const colores = [
                'red', 'green', 'blue', 'olive', 'magenta', 'brown'
            ]

            setCharData({
                labels,
                datasets: [
                    {
                        label: 'Valor total según tipo de producto',
                        data: values,
                        fill: true,
                        backgroundColor: colores.slice(0, values.length),
                borderWidth: 1
                    },
                ],
            })

        })
    }, [])

    if (!charData ) return <p>Cargando datos...</p>
    
    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'buttom'
            }
        }
    }
    return (
        <div  className='flex flex-col items-center gap-10 p-4'>
                        <div className='w-200 h-72'>
                <h2 className='text-center mb-2 font-semibold'>Valor minimo segun el tipo de producto visto desde una grafica de tipo PIE</h2>
               <Pie data={charData} options={options}></Pie>
</div>
            <div className='w-200 h-72'><h2 className='text-center mb-2 font-semibold'>Valor minimo segun el tipo de producto visto desde una grafica de tipo DOGNUT</h2>
<Doughnut data={charData} options={options}></Doughnut>
</div>
        </div>
    )
}
