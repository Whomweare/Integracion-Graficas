'use client'
import { valorTotal } from '@/app/servicios/api'
import React, { useEffect, useState } from 'react'
import { Radar } from 'react-chartjs-2'
import {
    Chart as ChartJS,
    RadialLinearScale,
    PointElement,
    LineElement,
    Filler,
    Tooltip,
    Legend,
    Title,
} from 'chart.js'

ChartJS.register(
    RadialLinearScale,
    PointElement,
    LineElement,
    Filler,
    Tooltip,
    Legend,
    Title
)

interface RadarChartData {
    labels: string[]
    datasets: {
        label: string
        data: number[]
        fill: boolean
        backgroundColor: string
        borderColor: string
        pointBackgroundColor: string
        pointBorderColor: string
        pointHoverBackgroundColor: string
        pointHoverBorderColor: string
    }[]
}

export default function Page() {
    const [charData, setCharData] = useState<RadarChartData>({
        labels: [],
        datasets: [],
    })

    useEffect(() => {
        valorTotal().then((data) => {
            const labels = data.map((item: any) => item.productType)
            const values = data.map((item: any) => parseFloat(item.total))

            setCharData({
                labels: labels,
                datasets: [
                    {
                        label: 'Valor total según tipo de producto',
                        data: values,
                        fill: true,
                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                        borderColor: 'rgb(54, 162, 235)',
                        pointBackgroundColor: 'rgb(54, 162, 235)',
                        pointBorderColor: '#fff',
                        pointHoverBackgroundColor: '#fff',
                        pointHoverBorderColor: 'rgb(54, 162, 235)',
                    },
                ],
            })
        })
    }, [])

    return (
        <div>
            <Radar data={charData} />
        </div>
    )
}
